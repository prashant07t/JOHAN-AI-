package com.johanai.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.johanai.assistant.ui.JohanApp
import com.johanai.assistant.ui.theme.JohanTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JohanTheme {
                Surface(color = MaterialTheme.colorScheme.background) { JohanApp() }
            }
        }
    }
}
