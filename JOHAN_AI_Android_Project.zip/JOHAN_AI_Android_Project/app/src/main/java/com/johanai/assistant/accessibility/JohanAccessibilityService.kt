package com.johanai.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JohanAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event observation is intentionally limited. Screen content is not uploaded automatically.
    }
    override fun onInterrupt() {}

    fun findAndClick(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(label)
        val node = matches.firstOrNull { it.isClickable } ?: matches.firstOrNull()
        return node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    fun scrollForward(): Boolean =
        rootInActiveWindow?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true
}
