package com.johanai.assistant.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class GeminiRepository {
    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS).build()

    suspend fun ask(config: Config, history: List<ChatMessage>, prompt: String): String =
        withContext(Dispatchers.IO) {
            if (config.apiKey.isBlank()) throw IllegalStateException("Add your Gemini API key in Settings first.")
            val contents = JSONArray()
            history.takeLast(16).forEach { msg ->
                if (msg.text.isNotBlank()) contents.put(JSONObject()
                    .put("role", if (msg.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", msg.text))))
            }
            contents.put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", prompt))))
            val system = "You are JOHAN, a caring, sweet, intelligent female AI companion. " +
                "Be natural, supportive, friendly and playful without claiming to be human. " +
                "Understand Hindi, English and Hinglish. Personality: ${config.personality}. " +
                "Preferred language: ${config.language}."
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", config.temperature))
                .toString().toRequestBody("application/json".toMediaType())
            val url = "https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent?key=${config.apiKey}"
            val request = Request.Builder().url(url).post(body).build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) throw IOException("Gemini error ${response.code}: ${extractError(raw)}")
                val json = JSONObject(raw)
                json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                    ?.optJSONObject(0)?.optString("text")
                    ?.takeIf { it.isNotBlank() }
                    ?: throw IOException("Gemini returned an empty response.")
            }
        }

    suspend fun test(config: Config): String = ask(config, emptyList(), "Reply with: Connection successful. I am JOHAN.")
    private fun extractError(raw: String): String = try {
        JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw.take(240)
    } catch (_: Exception) { raw.take(240) }
}
