package com.johanai.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("johan_settings")

class SettingsStore(private val context: Context) {
    private val apiKey = stringPreferencesKey("gemini_api_key")
    private val model = stringPreferencesKey("gemini_model")
    private val language = stringPreferencesKey("language")
    private val personality = stringPreferencesKey("personality")
    private val temperature = floatPreferencesKey("temperature")

    suspend fun save(key: String, modelName: String, lang: String, persona: String, temp: Float) {
        context.dataStore.edit {
            it[apiKey] = key.trim()
            it[model] = modelName
            it[language] = lang
            it[personality] = persona
            it[temperature] = temp.coerceIn(0f, 1f)
        }
    }

    suspend fun read(): Config = context.dataStore.data.map {
        Config(it[apiKey] ?: "", it[model] ?: "gemini-2.0-flash",
            it[language] ?: "Auto / Hinglish", it[personality] ?: "Caring, warm and intelligent",
            it[temperature] ?: 0.7f)
    }.first()
}

data class Config(
    val apiKey: String,
    val model: String,
    val language: String,
    val personality: String,
    val temperature: Float
)
