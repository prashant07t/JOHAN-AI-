package com.johanai.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.johanai.assistant.voice.VoiceController

@Composable
fun JohanApp(vm: JohanViewModel = viewModel()) {
    var tab by remember { mutableStateOf("Home") }
    val context = LocalContext.current
    var voice by remember { mutableStateOf<VoiceController?>(null) }
    var draft by remember { mutableStateOf("") }
    val status by vm.status.collectAsState()
    val messages by vm.messages.collectAsState()
    val config by vm.config.collectAsState()
    val busy by vm.busy.collectAsState()
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) voice?.listen()
    }
    DisposableEffect(Unit) {
        voice = VoiceController(context, { spoken -> draft = spoken; vm.send(spoken) }, { vm.run { } })
        onDispose { voice?.destroy(); voice = null }
    }

    Scaffold(
        containerColor = Color(0xFF070914),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF10152A)) {
                listOf("Home", "Chat", "Coding", "History", "Settings").forEach { name ->
                    val icon = when(name) {
                        "Home" -> Icons.Default.Home; "Chat" -> Icons.Default.Chat
                        "Coding" -> Icons.Default.Code; "History" -> Icons.Default.History
                        else -> Icons.Default.Settings
                    }
                    NavigationBarItem(selected = tab == name, onClick = { tab = name },
                        icon = { Icon(icon, null) }, label = { Text(name) })
                }
            }
        }
    ) { padding ->
        when(tab) {
            "Home" -> HomeScreen(status, busy, onChat = { tab = "Chat" }, onMic = {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) voice?.listen()
                else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }, onCoding = { tab = "Coding" })
            "Chat" -> ChatScreen(messages.map { it.role to it.text }, draft, { draft = it }, busy,
                { val value = draft; draft = ""; if (!vm.handleCommand(value)) vm.send(value) },
                { if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) voice?.listen() else micPermission.launch(Manifest.permission.RECORD_AUDIO) },
                { voice?.stopSpeaking() })
            "Coding" -> CodingScreen { vm.send("Act as a programming expert. Help me with: $it") ; tab = "Chat" }
            "History" -> HistoryScreen(messages.size, { tab = "Chat" }, { vm.clearHistory() })
            else -> SettingsScreen(config.apiKey, config.model, config.language, config.personality, config.temperature,
                status, { k,m,l,p,t -> vm.saveSettings(k,m,l,p,t) }, { vm.testConnection() }, { context.startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }
    }
}

@Composable
private fun HomeScreen(status: String, busy: Boolean, onChat: () -> Unit, onMic: () -> Unit, onCoding: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Text("JOHAN AI", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color(0xFFEAF0FF))
        Text("YOUR PERSONAL AI COMPANION", color = Color(0xFF8C9BC7), style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(42.dp))
        Box(Modifier.size(220.dp).background(Brush.radialGradient(listOf(Color(0xFF604CFF), Color(0xFF1D2C69), Color.Transparent)), CircleShape),
            contentAlignment = Alignment.Center) {
            Box(Modifier.size(138.dp).background(Brush.linearGradient(listOf(Color(0xFF8E9CFF), Color(0xFF6C4DDB))), CircleShape),
                contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(62.dp)) }
        }
        Spacer(Modifier.height(22.dp))
        Text(if (busy) "Thinking…" else status, color = Color(0xFF9DAEFF))
        Spacer(Modifier.height(28.dp))
        Button(onClick = onChat, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Default.Chat, null); Spacer(Modifier.width(8.dp)); Text("Start chatting")
        }
        OutlinedButton(onClick = onMic, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("Talk to JOHAN")
        }
        OutlinedButton(onClick = onCoding, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Default.Code, null); Spacer(Modifier.width(8.dp)); Text("Coding assistant")
        }
        Spacer(Modifier.weight(1f))
        Text("A little intelligence, a lot of heart ✦", color = Color(0xFF69779F))
    }
}

@Composable
private fun ChatScreen(messages: List<Pair<String,String>>, draft: String, onDraft: (String)->Unit,
                       busy: Boolean, onSend: ()->Unit, onMic: ()->Unit, onStop: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Chat with JOHAN", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(messages) { (role, text) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = if(role == "user") Color(0xFF202B50) else Color(0xFF131B32)),
                    shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(13.dp)) {
                        Text(if(role == "user") "YOU" else "JOHAN", color = Color(0xFF9EACFF), style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(4.dp)); Text(text)
                    }
                }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f),
                placeholder = { Text("Message JOHAN…") }, maxLines = 4)
            IconButton(onClick = onMic) { Icon(Icons.Default.Mic, "Speak") }
            IconButton(onClick = onSend, enabled = !busy) { Icon(Icons.Default.Send, "Send") }
        }
        TextButton(onClick = onStop) { Text("Stop speaking") }
    }
}

@Composable
private fun CodingScreen(onSubmit: (String)->Unit) {
    var language by remember { mutableStateOf("Python") }
    var task by remember { mutableStateOf("Write a program that ") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Coding Studio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Generate, explain, debug or improve code with JOHAN.")
        Spacer(Modifier.height(18.dp))
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(value = language, onValueChange = {}, readOnly = true, label = { Text("Language") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                listOf("Python","Java","Kotlin","C","C++","HTML","CSS","JavaScript","SQL").forEach {
                    DropdownMenuItem(text = { Text(it) }, onClick = { language = it; expanded = false })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(task, { task = it }, modifier = Modifier.fillMaxWidth().weight(1f),
            label = { Text("What should JOHAN do?") })
        Button(onClick = { onSubmit("Language: $language. $task") }, modifier = Modifier.fillMaxWidth()) { Text("Ask JOHAN") }
    }
}

@Composable
private fun HistoryScreen(count: Int, onOpen: ()->Unit, onClear: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Conversation history", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("$count saved messages")
        Spacer(Modifier.height(16.dp))
        Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) { Text("View conversation") }
        OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("Clear all history") }
    }
}

@Composable
private fun SettingsScreen(apiKey: String, model: String, language: String, personality: String,
                           temperature: Float, status: String, onSave: (String,String,String,String,Float)->Unit,
                           onTest: ()->Unit, onAccessibility: ()->Unit) {
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    var modelName by remember(model) { mutableStateOf(model) }
    var lang by remember(language) { mutableStateOf(language) }
    var persona by remember(personality) { mutableStateOf(personality) }
    var temp by remember(temperature) { mutableFloatStateOf(temperature) }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Gemini configuration", color = Color(0xFF9EACFF)) }
        item { OutlinedTextField(key, { key = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true) }
        item { OutlinedTextField(modelName, { modelName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true) }
        item { OutlinedTextField(lang, { lang = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Response language") }) }
        item { OutlinedTextField(persona, { persona = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Personality") }) }
        item { Text("Creativity: ${(temp * 100).toInt()}%") }
        item { Slider(value = temp, onValueChange = { temp = it }) }
        item { Button(onClick = { onSave(key, modelName, lang, persona, temp) }, modifier = Modifier.fillMaxWidth()) { Text("Save configuration") } }
        item { OutlinedButton(onClick = onTest, modifier = Modifier.fillMaxWidth()) { Text("Test Gemini connection") } }
        item { Text(status, color = Color(0xFF9EACFF)) }
        item { HorizontalDivider() }
        item { Text("Accessibility screen actions", color = Color(0xFF9EACFF)) }
        item { Text("Enable JOHAN AI in Android Settings → Accessibility. Android may restrict actions in secure or protected screens. Screen text is not automatically sent to Gemini.") }
        item { OutlinedButton(onClick = onAccessibility, modifier = Modifier.fillMaxWidth()) { Text("Open Accessibility settings") } }
        item { Text("Security: API keys stored locally using DataStore preferences. This is not encrypted secret storage; a key embedded or entered in a client app can be extracted. Use a backend proxy for production.") }
    }
}
