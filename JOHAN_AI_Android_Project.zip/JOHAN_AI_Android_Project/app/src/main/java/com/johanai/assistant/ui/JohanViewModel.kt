package com.johanai.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.johanai.assistant.data.*
import com.johanai.assistant.util.DeviceActions
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class JohanViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = ChatDatabase.get(app).chatDao()
    private val settings = SettingsStore(app)
    private val gemini = GeminiRepository()
    private val actions = DeviceActions(app)

    val messages = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _status = MutableStateFlow("Ready")
    val status = _status.asStateFlow()
    private val _config = MutableStateFlow(Config("", "gemini-2.0-flash", "Auto / Hinglish", "Caring, warm and intelligent", .7f))
    val config = _config.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()

    init { viewModelScope.launch { _config.value = settings.read() } }

    fun saveSettings(key: String, model: String, language: String, personality: String, temperature: Float) {
        viewModelScope.launch {
            val next = Config(key, model, language, personality, temperature)
            settings.save(key, model, language, personality, temperature)
            _config.value = next
            _status.value = "Settings saved"
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            _busy.value = true
            try { _status.value = gemini.test(_config.value) }
            catch (e: Exception) { _status.value = e.message ?: "Connection failed" }
            finally { _busy.value = false }
        }
    }

    fun send(text: String) {
        val prompt = text.trim()
        if (prompt.isEmpty() || _busy.value) return
        viewModelScope.launch {
            dao.insert(ChatMessage(role = "user", text = prompt))
            _busy.value = true
            _status.value = "JOHAN is thinking…"
            try {
                val answer = gemini.ask(_config.value, messages.value, prompt)
                dao.insert(ChatMessage(role = "assistant", text = answer))
                _status.value = "Online"
            } catch (e: Exception) {
                dao.insert(ChatMessage(role = "assistant", text = "I couldn't reach my AI brain: ${e.message ?: "Unknown error"}"))
                _status.value = "Offline / check settings"
            } finally { _busy.value = false }
        }
    }

    fun clearHistory() { viewModelScope.launch { dao.clear(); _status.value = "History cleared" } }
    fun handleCommand(text: String): Boolean {
        val lower = text.lowercase()
        return when {
            lower.startsWith("open ") -> { _status.value = actions.openApp(lower.removePrefix("open ")); true }
            lower.startsWith("search youtube ") -> { actions.searchYouTube(text.substringAfter("search youtube ")); _status.value = "Searching YouTube"; true }
            lower.startsWith("play ") -> { actions.searchYouTube(text.removePrefix("play ")); _status.value = "Opening YouTube results"; true }
            lower.startsWith("search google ") -> { actions.searchWeb(text.substringAfter("search google ")); _status.value = "Searching Google"; true }
            else -> false
        }
    }
}
