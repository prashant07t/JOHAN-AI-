package com.johanai.assistant.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7C8CFF), secondary = Color(0xFFB28CFF),
    background = Color(0xFF070914), surface = Color(0xFF11162A),
    onBackground = Color(0xFFEAF0FF), onSurface = Color(0xFFEAF0FF)
)

@Composable
fun JohanTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = Typography(), content = content)
}
