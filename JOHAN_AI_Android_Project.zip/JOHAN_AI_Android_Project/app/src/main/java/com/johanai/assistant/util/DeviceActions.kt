package com.johanai.assistant.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings

class DeviceActions(private val context: Context) {
    fun openApp(query: String): String {
        val apps = listOf(
            Triple("chrome", "com.android.chrome", "Chrome"),
            Triple("youtube", "com.google.android.youtube", "YouTube"),
            Triple("whatsapp", "com.whatsapp", "WhatsApp"),
            Triple("instagram", "com.instagram.android", "Instagram")
        )
        val found = apps.firstOrNull { query.contains(it.first, true) }
        if (found != null) {
            val intent = context.packageManager.getLaunchIntentForPackage(found.second)
            if (intent != null) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent); return "Opening ${found.third}." }
        }
        val launchable = context.packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .firstOrNull { context.packageManager.getApplicationLabel(it).toString().contains(query, true) }
        if (launchable != null) {
            context.packageManager.getLaunchIntentForPackage(launchable.packageName)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(it)
                return "Opening ${context.packageManager.getApplicationLabel(launchable)}."
            }
        }
        return "I couldn't find that installed app."
    }

    fun searchWeb(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun searchYouTube(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun accessibilitySettings() {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
